"""InteractiveDriftCompensation plugin bundle."""
