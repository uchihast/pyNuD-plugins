"""ReferenceObjectCropper plugin bundle."""
