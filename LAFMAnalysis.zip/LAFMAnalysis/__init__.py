"""LAFMAnalysis plugin bundle."""
