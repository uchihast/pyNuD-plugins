"""FilamentAnalysis plugin bundle."""
