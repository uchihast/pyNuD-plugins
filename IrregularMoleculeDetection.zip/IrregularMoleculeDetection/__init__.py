"""IrregularMoleculeDetection plugin bundle."""
