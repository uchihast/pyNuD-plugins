"""AFMMovieEditor plugin bundle."""
