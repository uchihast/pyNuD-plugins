"""DwellAnalysis plugin bundle."""
