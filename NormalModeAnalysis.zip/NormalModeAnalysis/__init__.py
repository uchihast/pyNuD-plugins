"""NormalModeAnalysis plugin bundle."""
