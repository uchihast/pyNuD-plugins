"""SpotAnalysis plugin bundle."""
