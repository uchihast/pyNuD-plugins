"""ParticleAnalysis plugin bundle."""
